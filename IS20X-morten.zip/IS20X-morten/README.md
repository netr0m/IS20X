# Mortens development branch
## Stuff2do
Integrate glassfish/payaraserver with Java

Display data from database in Overlook

Input data from forms in Grading to database when submitted

etc.
